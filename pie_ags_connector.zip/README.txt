PIE — CoJ AGS Aerial Connector

Files:
- ags_client.py
- test_ags_client.py

Dependencies:
    pip install httpx pytest

Run tests:
    pytest -q test_ags_client.py

PIE integration:
    from ags_client import fetch_ags_aerial_image

    image_bytes = fetch_ags_aerial_image(
        latitude=-25.99,
        longitude=28.07,
        radius_m=100,
    )

Feed image_bytes into the existing PIE vision/image-analysis pipeline
with source type "ags_aerial".

Verified AGS endpoint:
https://ags.joburg.org.za/server/rest/services/AerialPhotography/2023/ImageServer

The service advertises:
- ImageServer
- 0.15 m pixel size
- Export Image operation
- EPSG:3857 / WKID 102100
- max image height 4100
- max image width 15000
