import httpx
import pytest

from ags_client import AGSAerialClient, AGSImageRequest, AGSError


def test_web_mercator_conversion_midrand():
    x, y = AGSAerialClient.wgs84_to_web_mercator(-25.99, 28.07)

    assert x == pytest.approx(3124738.1066, abs=0.1)
    assert y == pytest.approx(-2997842.4534, abs=0.1)


def test_bbox_is_centered_on_point():
    x, y = AGSAerialClient.wgs84_to_web_mercator(-25.99, 28.07)
    xmin, ymin, xmax, ymax = AGSAerialClient.bbox_from_point(-25.99, 28.07, 100)

    assert xmin == pytest.approx(x - 100)
    assert ymin == pytest.approx(y - 100)
    assert xmax == pytest.approx(x + 100)
    assert ymax == pytest.approx(y + 100)


def test_export_params_use_image_server_contract():
    client = AGSAerialClient()
    params = client.build_export_params(
        AGSImageRequest(latitude=-25.99, longitude=28.07)
    )

    assert params["bboxSR"] == "3857"
    assert params["imageSR"] == "3857"
    assert params["size"] == "1600,1600"
    assert params["format"] == "jpg"
    assert params["f"] == "image"


def test_rejects_height_above_ags_limit():
    client = AGSAerialClient()

    with pytest.raises(ValueError, match="4100"):
        client.build_export_params(
            AGSImageRequest(
                latitude=-25.99,
                longitude=28.07,
                height=4101,
            )
        )


def test_export_returns_image_bytes():
    def handler(request: httpx.Request) -> httpx.Response:
        assert "/AerialPhotography/2023/ImageServer/exportImage" in str(request.url)
        return httpx.Response(
            200,
            headers={"content-type": "image/jpeg"},
            content=b"\xff\xd8fake-jpeg\xff\xd9",
        )

    client = AGSAerialClient(transport=httpx.MockTransport(handler))
    result = client.export_image(
        AGSImageRequest(latitude=-25.99, longitude=28.07)
    )

    assert result.startswith(b"\xff\xd8")


def test_export_rejects_non_image_response():
    def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(
            200,
            headers={"content-type": "application/json"},
            json={"error": {"message": "bad request"}},
        )

    client = AGSAerialClient(transport=httpx.MockTransport(handler))

    with pytest.raises(AGSError, match="did not return an image"):
        client.export_image(
            AGSImageRequest(latitude=-25.99, longitude=28.07)
        )
