from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import httpx


WEB_MERCATOR_RADIUS = 6378137.0


class AGSError(RuntimeError):
    """Raised when the CoJ AGS imagery service cannot satisfy a request."""


@dataclass(frozen=True)
class AGSImageRequest:
    latitude: float
    longitude: float
    radius_m: float = 100.0
    width: int = 1600
    height: int = 1600
    year: int = 2023
    image_format: str = "jpg"


class AGSAerialClient:
    """
    City of Johannesburg AGS aerial imagery connector.

    Uses the ArcGIS ImageServer Export Image operation:
      /AerialPhotography/{year}/ImageServer/exportImage

    Coordinates supplied to this class are WGS84 lat/lon.
    The AGS 2023 imagery service uses EPSG:3857 / WKID 102100.
    """

    BASE_URL = (
        "https://ags.joburg.org.za/server/rest/services/"
        "AerialPhotography/{year}/ImageServer"
    )

    def __init__(
        self,
        *,
        timeout_s: float = 20.0,
        transport: Optional[httpx.BaseTransport] = None,
    ) -> None:
        self.timeout_s = timeout_s
        self._transport = transport

    @staticmethod
    def wgs84_to_web_mercator(latitude: float, longitude: float) -> tuple[float, float]:
        if not -90.0 <= latitude <= 90.0:
            raise ValueError("latitude must be between -90 and 90")
        if not -180.0 <= longitude <= 180.0:
            raise ValueError("longitude must be between -180 and 180")

        # Web Mercator is undefined at the poles. ArcGIS/Google convention
        # clamps to the practical Web Mercator latitude limit.
        latitude = max(min(latitude, 85.05112878), -85.05112878)

        x = WEB_MERCATOR_RADIUS * math.radians(longitude)
        y = WEB_MERCATOR_RADIUS * math.log(
            math.tan(math.pi / 4.0 + math.radians(latitude) / 2.0)
        )
        return x, y

    @classmethod
    def bbox_from_point(
        cls, latitude: float, longitude: float, radius_m: float
    ) -> tuple[float, float, float, float]:
        if radius_m <= 0:
            raise ValueError("radius_m must be > 0")

        x, y = cls.wgs84_to_web_mercator(latitude, longitude)
        return (x - radius_m, y - radius_m, x + radius_m, y + radius_m)

    def build_export_params(self, request: AGSImageRequest) -> dict[str, str]:
        if request.width <= 0 or request.height <= 0:
            raise ValueError("width and height must be > 0")

        # AGS 2023 advertises Max Image Height 4100 and Max Image Width 15000.
        if request.height > 4100:
            raise ValueError("height exceeds AGS advertised maximum of 4100")
        if request.width > 15000:
            raise ValueError("width exceeds AGS advertised maximum of 15000")

        xmin, ymin, xmax, ymax = self.bbox_from_point(
            request.latitude, request.longitude, request.radius_m
        )

        return {
            "bbox": f"{xmin:.6f},{ymin:.6f},{xmax:.6f},{ymax:.6f}",
            "bboxSR": "3857",
            "imageSR": "3857",
            "size": f"{request.width},{request.height}",
            "format": request.image_format,
            "interpolation": "RSP_BilinearInterpolation",
            "returnSquarePixels": "true",
            "f": "image",
        }

    def export_image(self, request: AGSImageRequest) -> bytes:
        url = f"{self.BASE_URL.format(year=request.year)}/exportImage"
        params = self.build_export_params(request)

        try:
            with httpx.Client(
                timeout=self.timeout_s,
                follow_redirects=True,
                transport=self._transport,
            ) as client:
                response = client.get(url, params=params)
        except httpx.HTTPError as exc:
            raise AGSError(f"AGS request failed: {exc}") from exc

        if response.status_code != 200:
            raise AGSError(
                f"AGS returned HTTP {response.status_code}: "
                f"{response.text[:300]}"
            )

        content_type = response.headers.get("content-type", "").lower()
        if not content_type.startswith("image/"):
            raise AGSError(
                "AGS did not return an image. "
                f"content-type={content_type!r}; body={response.text[:300]!r}"
            )

        if not response.content:
            raise AGSError("AGS returned an empty image")

        return response.content

    def export_image_to_file(
        self, request: AGSImageRequest, destination: str | Path
    ) -> Path:
        destination = Path(destination)
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(self.export_image(request))
        return destination


def fetch_ags_aerial_image(
    latitude: float,
    longitude: float,
    *,
    radius_m: float = 100.0,
    width: int = 1600,
    height: int = 1600,
    year: int = 2023,
) -> bytes:
    """
    Convenience entry point for PIE's image pipeline.

    Example:
        image_bytes = fetch_ags_aerial_image(-25.99, 28.07)
        result = image_pipeline.analyse_bytes(image_bytes, source="ags_aerial")
    """
    client = AGSAerialClient()
    return client.export_image(
        AGSImageRequest(
            latitude=latitude,
            longitude=longitude,
            radius_m=radius_m,
            width=width,
            height=height,
            year=year,
        )
    )
